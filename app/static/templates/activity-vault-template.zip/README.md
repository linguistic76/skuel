# SKUEL Activity Vault Template

This zip provides YAML templates for directly creating Activity Domain entities
in SKUEL via the `/upload` page. It is for power users and programmatic workflows.

**The primary way to use SKUEL is through the Obsidian vault.**
Download the `skuel/` vault, open it in Obsidian as its own vault, and write
daily notes — SKUEL extracts tasks, habits, goals, and other entities from your
checkboxes automatically. This zip is for bulk creation or cases where you want
to define entities explicitly in YAML without going through Obsidian.

---

## Folder Structure

```
tasks/         — Work to be done
goals/         — Outcomes to achieve
habits/        — Behaviors to build
events/        — Time commitments to keep
choices/       — Decisions to make
principles/    — Values to embody
user_entries/  — Submissions, reflections, daily notes
```

---

## How to Use

1. Author YAML files in the appropriate folders.
2. Each file must include a `type` field matching the domain (e.g., `type: Task`).
3. Upload files at `/upload` in the SKUEL app.

---

## Required Fields

| Type       | Required Fields              |
|------------|------------------------------|
| Task       | `title`                      |
| Goal       | `title`                      |
| Habit      | `title`                      |
| Event      | `title`                      |
| Choice     | `title`                      |
| Principle  | `name`, `statement`          |
| UserEntry  | `pipeline`                   |

All other fields are optional. See the example files for common fields.

---

## UserEntry Pipelines

`pipeline:` controls what SKUEL does with the entry after ingestion:

| Pipeline | What it does |
|---|---|
| `none` | Persisted as-is — plain submission or text note |
| `extract_activities` | Parses checkbox lines into Tasks, Habits, Goals, etc. — the Obsidian daily note pipeline |
| `teacher_review` | Queued for teacher feedback via your groups |
| `llm_summary` | Sent to the LLM for a structured summary |

Audio pipelines (`transcribe`, `transcribe_and_structure`) use the audio-upload
flow and are rejected by `/upload`, which is YAML-only.

---

## UserEntry Audience

Control who sees the entry with an `audience:` field:

| Value | Who sees it |
|---|---|
| `private` | Only you |
| `teachers` (default) | Every group's teachers you belong to as a student |
| `group:<group_uid>` | One specific group |
| `public` | Your portfolio |

---

## File Naming

Name files descriptively: `task_read-chapter-3.yaml`, `habit_morning-journal.yaml`.
If no `uid` field is set, one is generated from the filename.

---

## Tips

- Edit these files in Obsidian, VS Code, or any text editor.
- Upload as many files as you like in a single batch (max 50 per upload).
- Re-uploading a file with the same `uid` updates the existing entity.
- Use the `connections` field to link entities across domains.
